This directory should contain annotator related files:
* `annotator.py` - Annotator control script; spawns AnnTools runner
* `run.py` - Runs AnnTools and updates environment on completion
* `ann_config.ini` - Common configuration options for annotator.py and run.py